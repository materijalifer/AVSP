
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import org.apache.commons.codec.digest.DigestUtils;

/**
 *
 * @author petar
 */
public class SimHashBuckets {

    /**
     * @param args the command line arguments
     */
    
     public String[] generate_tokens(String text){
         String[] splited = text.split("\\s+");
         return splited;
     }
     
     public String concatenateDigits(int[] digits){
          StringBuilder sb = new StringBuilder(digits.length);
            for (int digit : digits) {
              sb.append(digit);
            }
            return sb.toString();
     }
      
    public String simhash(String text){
        int sh[] = new int[128];
       
        String[] tokens = generate_tokens(text);
        for(String token:tokens){
	      int pos = 0;
              byte[] hash = DigestUtils.md5(token);
              for(byte i:hash){
                  for(int j=0; j<8; j++){
                      if(((i >> (8 - 1 - j) ) & 1 )== 1){
                         sh[pos++]+=1; 
                      }else sh[pos++]-=1;
                  }
              }   
        }
        for(int i=0; i<sh.length; i++){
            if(sh[i]>=0) sh[i]=1;
            else sh[i] = 0;           
        } 
        //return new BigInteger(concatenateDigits(sh), 2).toString(16);
        return concatenateDigits(sh);
    }
    
    
    //algoritam za racunanje razlike
    public static void diffHash(Map<Integer, Set<Integer>> candidates, ArrayList<String> hashList, String idHash, String distance ){
        int diffCount = 0;
        String hash = hashList.get(Integer.parseInt(idHash));
        char[] s1 = hash.toCharArray();
        
        Set<Integer> candidatesForI = new HashSet<>();
        candidatesForI = candidates.get(Integer.parseInt(idHash));
        
        for(Integer h:candidatesForI){
            
            char[] s2 = hashList.get(h).toCharArray();
            
            if (s2 == null || s1 == null) {
                throw new IllegalArgumentException("Strings must not be null");
            }

            if (s1.length != s2.length) {
                throw new IllegalArgumentException("Strings must have the same length");
            }

            int result = 0;
            for (int i=0; i<s1.length; i++) {
                if (s1[i] != s2[i]) result++;
            } 
            if(result<=Integer.parseInt(distance)) diffCount++;
        }    
        System.out.println(diffCount);
    }
    
    
    
    //metoda hash2int
    public static int hash2int(int bandwidth, String currHash){
         String r="";
                switch(bandwidth){
                    case 1:
                            r = currHash.substring(0, 16);
                            break;
                    case 2:
                            r = currHash.substring(16,32);
                            break;
                    case 3: 
                            r = currHash.substring(32,48);
                            break;
                    case 4:
                            r = currHash.substring(48,64);
                            break;
                    case 5: 
                            r = currHash.substring(64,80);
                            break;
                    case 6:
                            r = currHash.substring(80,96);
                            break;
                    case 7: 
                            r = currHash.substring(96,112);
                            break;
                    case 8: 
                            r = currHash.substring(112, 128);
                            break;
                }
                //System.out.println(Integer.parseInt(r,2));
                int test = Integer.parseInt(r,2);
                return Integer.parseInt(r, 2);
    } 
    
    
    //metoda LSH
    public static Map<Integer, Set<Integer>> LSH(ArrayList<String> hashList){
        
        Map<Integer, Set<Integer>> candidates = new HashMap<Integer, Set<Integer>>();
        
        for(int bandwidth = 1; bandwidth<=8; bandwidth++){
            Map<Integer, Set<Integer>> buckets = new HashMap<Integer, Set<Integer>>();
            for(int currID=0; currID<=hashList.size()-1; currID++){
                String currHash = hashList.get(currID);
                int val = hash2int(bandwidth, currHash);
                //System.out.println(val);
                Set<Integer> bucketTexts = new HashSet<>();
                if(buckets.get(val)!=null){
                    bucketTexts = buckets.get(val);
                         for(Integer textID:bucketTexts){
                             if(candidates.get(currID)==null){
                                 candidates.put(currID, new HashSet<>());
                             }
                             if(!candidates.get(currID).contains(textID))  candidates.get(currID).add(textID);
                             
                             if(candidates.get(textID)== null){
                                 candidates.put(textID, new HashSet<>());
                             }
                             
                             if(!candidates.get(textID).contains(textID)) candidates.get(textID).add(currID);
                         }        
                }
                else {
                    bucketTexts = new HashSet<>();
                }
                bucketTexts.add(currID);
                buckets.put(val, bucketTexts);
            }
        }
        return candidates;
    }
    
     public static void main(String[] args) throws IOException {
        SimHashBuckets simhash = new SimHashBuckets();
        
        Map<Integer, Set<Integer>> candidates = new HashMap<>();
        
        //BufferedReader br = null;
        ArrayList<String> hashArray = new ArrayList<String>();
        int i = 0;
        String[] query = new String[2];
        Scanner sc = new Scanner(System.in);
        //br = new BufferedReader(new FileReader("C:\\Users\\petar\\Documents\\NetBeansProjects\\SimHashBuckets\\test2b\\R.in"));
        //String numberOfTextLines = br.readLine();
        String numberOfTextLines = sc.nextLine();
        int numberOfQueries = 0;
        
        for(i = 0; i<Integer.parseInt(numberOfTextLines); i++){
            hashArray.add(simhash.simhash(sc.nextLine()));
        }
        
        candidates = LSH(hashArray);
         
        numberOfQueries = Integer.parseInt(sc.nextLine());
        for(i=0; i<numberOfQueries; i++){
            query = sc.nextLine().split(" ");
            //System.out.println(query[0] + " " + query[1]);
            diffHash(candidates, hashArray, query[0], query[1]);
            Arrays.fill(query, null);            
        }
        if (sc.nextLine() != null)sc.close();
        
    }   
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author 
 */
public class PCY {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PCY pcy = new PCY();
        
        BufferedReader br = null;
        try {
                String sCurrentLine;
                br = new BufferedReader(new InputStreamReader(System.in));
                int basketNumber = Integer.parseInt(br.readLine());
                float s = Float.parseFloat(br.readLine());
                int casesNumber = Integer.parseInt(br.readLine());
                int tolerance = (int) Math.floor(s * basketNumber);
                
                List<Integer[]> baskets = new ArrayList<Integer[]>();
                while ((sCurrentLine = br.readLine()) != null) {
                     String[] subjects = sCurrentLine.split(" ");
                     Integer[] intSubjects = new Integer[subjects.length];
                     for(int i = 0; i < subjects.length; i++){
                        intSubjects[i] = Integer.parseInt(subjects[i]);
                     }
                     baskets.add(intSubjects);
                     intSubjects = null;
                     subjects = null;
                }
                              
                //prvi prolaz
                Map<Integer, Integer> subjectNumbers = new HashMap<>();
                for(Integer[] numbers:baskets){
                    for(Integer number:numbers){
                        if(!subjectNumbers.containsKey(number)){
                            subjectNumbers.put(number, 1);
                        }else{
                            subjectNumbers.put(number, (subjectNumbers.get(number)+1));
                        }
                    }
                }
                
                int m = 0;
                for (Map.Entry entry : subjectNumbers.entrySet()) {
                    if (((int) entry.getValue())>=tolerance) m++;
                }
                
                //drugi prolaz
                Map<Integer, Integer> cases = new HashMap<>();
                Integer pI, pJ, k, numbersSize;
                for(Integer[] numbers:baskets){
                    numbersSize = numbers.length;
                    for(int i = 0; i<numbersSize; i++){
                        for(int j =i+1; j<numbersSize; j++ ){
                            pI = numbers[i];
                            pJ = numbers[j];
                            if((subjectNumbers.get(pI)>=tolerance)&&(subjectNumbers.get(pJ)>=tolerance)){
                                k = ((pI*subjectNumbers.size())+pJ) % casesNumber;
                                if(!cases.containsKey(k)){
                                    cases.put(k, 1);
                                }else{
                                    cases.put(k, (cases.get(k)+1));
                                }
                            }
                        }
                    }
                }
                
                //treci prolaz
                Map<String, Integer> pairs = new HashMap<>();
                int oftenPairNumber =0;
                
                for(Integer[] numbers:baskets){
                    numbersSize = numbers.length;
                    for(int i = 0; i<numbersSize; i++){
                        for(int j =i+1; j<numbersSize; j++ ){
                            pI = numbers[i];
                            pJ = numbers[j];
                            String subjectPair = "["+pI+","+pJ+"]";
                            if((subjectNumbers.get(pI)>=tolerance)&&(subjectNumbers.get(pJ)>=tolerance)){
                                k = ((pI*subjectNumbers.size())+pJ) % casesNumber;
                                if(cases.get(k)>=tolerance){
                                    if(!pairs.containsKey(subjectPair)){
                                        pairs.put(subjectPair, 1);
                                    }else{
                                        pairs.put(subjectPair, (pairs.get(subjectPair)+1));
                                    }
                                }
                            }
                        }
                    }
                }
                
                System.out.println((m*(m-1))/2);
                System.out.println(pairs.size());
                
                Object[] a = pairs.entrySet().toArray();
                Arrays.sort(a, new Comparator() {
                public int compare(Object o1, Object o2) {
                    return ((Map.Entry<Integer, Integer>) o2).getValue().compareTo(
                            ((Map.Entry<Integer, Integer>) o1).getValue());
                }
                });
                for (Object e : a) {
                    System.out.println(((Map.Entry<Integer, Integer>) e).getValue());
                }
                
                
        } catch (IOException e) {
                e.printStackTrace();
        } finally {
                try {
                        if (br != null)br.close();
                } catch (IOException ex) {
                        ex.printStackTrace();
                }
        }      
    }
}
